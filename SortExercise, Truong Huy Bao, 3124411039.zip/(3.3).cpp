#include <stdio.h>
struct PhongThi {
    int soPhong;       // Số phòng (1 → 200)
    char nha;          // Nhà (A → Z)
    int khaNangChua;   // Khả năng chứa (10 → 250)
};
// Giảm dần về Khả năng chứa
void sapXepTheoKhaNangChuaGiamDan(PhongThi* danhSach, int soLuongPhong) {
    for (int i = 0; i < soLuongPhong - 1; i++) {
        for (int j = i + 1; j < soLuongPhong; j++) {
            if (danhSach[i].khaNangChua < danhSach[j].khaNangChua) {
                PhongThi temp = danhSach[i];
                danhSach[i] = danhSach[j];
                danhSach[j] = temp;
            }
        }
    }
}
// Tăng dần theo Nhà, các phong cùng Nhà tăng dần theo số Phòng
void sapXepTheoNhaVaSoPhongTangDan(PhongThi* danhSach, int soLuongPhong) {
    for (int i = 0; i < soLuongPhong - 1; i++) {
        for (int j = i + 1; j < soLuongPhong; j++) {
            if (danhSach[i].nha > danhSach[j].nha ||
                (danhSach[i].nha == danhSach[j].nha && danhSach[i].soPhong > danhSach[j].soPhong)) {
                PhongThi temp = danhSach[i];
                danhSach[i] = danhSach[j];
                danhSach[j] = temp;
            }
        }
    }
}
//Tăng dần theo Nhà, các phòng cùng Nhà giảm dần theo Khả năng chứa
void sapXepTheoNhaVaKhaNangChuaGiamDan(PhongThi* danhSach, int soLuongPhong) {
    for (int i = 0; i < soLuongPhong - 1; i++) {
        for (int j = i + 1; j < soLuongPhong; j++) {
            if (danhSach[i].nha > danhSach[j].nha ||
                (danhSach[i].nha == danhSach[j].nha && danhSach[i].khaNangChua < danhSach[j].khaNangChua)) {
                PhongThi temp = danhSach[i];
                danhSach[i] = danhSach[j];
            }
        }
    }
}
void inDanhSachPhongThi(PhongThi* danhSach, int soLuongPhong) {
    for (int i = 0; i < soLuongPhong; i++) {
        printf("Phong %d - Nha %c - Kha nang chua %d\n", danhSach[i].soPhong, danhSach[i].nha, danhSach[i].khaNangChua);
    }
}

 
int main() {
    PhongThi danhSach[] = {
        {1, 'A', 100},
        {2, 'B', 150},
        {3, 'A', 80},
        {4, 'C', 200},
        {5, 'B', 50},
        {6, 'D', 30},
        {7, 'A', 70},
        {8, 'D', 120},
        {9, 'C', 40},
        {10, 'B', 15}
        
    };
    int soLuongPhong = 10;

    printf("Danh sach sap xep theo kha nang chua giam dan:\n");
    sapXepTheoKhaNangChuaGiamDan(danhSach, soLuongPhong);
    inDanhSachPhongThi(danhSach, soLuongPhong);

    printf("\nDanh sach sap xep theo nha va so phong tang dan:\n");
    sapXepTheoNhaVaSoPhongTangDan(danhSach, soLuongPhong);
    inDanhSachPhongThi(danhSach, soLuongPhong);

    printf("\nDanh sach sap xep theo nha va kha nang chua giam dan:\n");
    sapXepTheoNhaVaKhaNangChuaGiamDan(danhSach, soLuongPhong);
    inDanhSachPhongThi(danhSach, soLuongPhong);

    return 0;
}
