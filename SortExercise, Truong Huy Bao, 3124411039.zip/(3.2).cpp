#include <stdio.h>

struct SoHang {
double heSo;  // Hệ số của số hạng
int bac;      // Bậc của số hạng (0 → 100)
};


void countingSort(SoHang* danhSach, int n, int exp) {
    SoHang output[n];
    int count[10] = {0};

    for (int i = 0; i < n; i++) {
        count[(danhSach[i].bac / exp) % 10]++;
    }
for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    for (int i = n - 1; i >= 0; i--) {
        output[count[(danhSach[i].bac / exp) % 10] - 1] = danhSach[i];
     count[(danhSach[i].bac / exp) % 10]--;
    }

    for (int i = 0; i < n; i++) {
        danhSach[i] = output[i];
    }
}

void radixSort(SoHang* danhSach, int n) {
    int maxBac = danhSach[0].bac;
    for (int i = 1; i < n; i++) {
        if (danhSach[i].bac > maxBac) {
            maxBac = danhSach[i].bac;
        }
    }

    for (int exp = 1; maxBac / exp > 0; exp *= 10) {
        countingSort(danhSach, n, exp);
    }
}

void inDanhSachSoHang(SoHang* danhSach, int soLuong) {
    for (int i = 0; i < soLuong; i++) {
        printf("He so: %lf, Bac: %d\n", danhSach[i].heSo, danhSach[i].bac);
    }
}

int main() {
    SoHang danhSach[] = {
        {3.0, 4},
        {1.0, 5},
        {4.8, 3},
        {5.6, 1},
        {1.2, 0}
    };
    int soLuong = 5;

    printf("Danh sach sap xep theo bac tang dan:\n");
    radixSort(danhSach, soLuong);
    inDanhSachSoHang(danhSach, soLuong);

    return 0;
}
