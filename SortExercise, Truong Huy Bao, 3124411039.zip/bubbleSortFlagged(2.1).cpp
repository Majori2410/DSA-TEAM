#include <iostream>
using namespace std;

void bubbleSortFlagged(int arr[], int n) {
    for (int i = 0; i < n-1; i++) {
        bool swapped = false;
        for (int j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                swap(arr[j], arr[j+1]);
                swapped = true;
            }
        }
        // Nếu không có phần tử nào được hoán đổi, mảng đã được sắp xếp
        if (!swapped) break;
    }
}

int main() {
    int arr[] = {39, 8, 5, 1, 3, 6, 9, 12, 4, 7, 10};
    int n = sizeof(arr) / sizeof(arr[0]);
    bubbleSortFlagged(arr, n);
    cout << "Bubble Sort có cờ: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
   return 0;
}

