#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Tính tổng các phần tử trong dòng
int sumRow(const vector<int>& row) {
    int sum = 0;
    for (int element : row) {
        sum += element;
    }
    return sum;
}

// Tìm dòng có tổng lớn nhất
int findRowWithMaxSum(const vector<vector<int>>& matrix) {
    int maxSum = -1;
    int rowIndex = -1;
    for (size_t i = 0; i < matrix.size(); ++i) {
        int currentSum = sumRow(matrix[i]);
        if (currentSum > maxSum) {
            maxSum = currentSum;
            rowIndex = i;
        }
    }
    return rowIndex;
}

// Sắp xếp các dòng dựa trên tổng các phần tử giảm dần
void sortRowsBySum(vector<vector<int>>& matrix) {
    sort(matrix.begin(), matrix.end(), [](const vector<int>& a, const vector<int>& b) {
        return sumRow(a) > sumRow(b);
    });
}

// Kiểm thử
void printMatrix(const vector<vector<int>>& matrix) {
    for (const auto& row : matrix) {
        for (int element : row) {
            cout << element << " ";
        }
        cout << endl;
    }
}
int main() {
    vector<vector<int>> matrix = {
        {4, 6, 8, 9},
        {5, 7, 11, 13},
        {15, 16, 17, 19},
        {2, 3, 5, 7}
    };

    // Tìm dòng có tổng lớn nhất
    int rowIndex = findRowWithMaxSum(matrix);
    cout << "Dòng có tổng lớn nhất: " << rowIndex << endl;

    // Sắp xếp các dòng dựa trên tổng các phần tử giảm dần
    sortRowsBySum(matrix);
    cout << "Ma trận sau khi sắp xếp:\n";
    printMatrix(matrix);

    return 0;
}


