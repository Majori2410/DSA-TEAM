#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

// Hàm tính tổng các chữ số của một số
int sumOfDigits(int num) {
    int sum = 0;
    while (num != 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}

// Hàm tìm giá trị lớn nhất trong mảng
int getMaxSum(const vector<int>& digitSums) {
    int maxSum = 0;
    for (int sum : digitSums) {
        maxSum = max(maxSum, sum);
    }
    return maxSum;
}

// Hàm sắp xếp Counting Sort
void countingSort(vector<int>& arr, const vector<int>& digitSums, int exp) {
    int n = arr.size();
    vector<int> output(n);
    vector<int> count(10, 0);

    for (int i = 0; i < n; i++) {
        int index = (digitSums[i] / exp) % 10;
        count[index]++;
    }

    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    for (int i = n - 1; i >= 0; i--) {
        int index = (digitSums[i] / exp) % 10;
        output[count[index] - 1] = arr[i];
count[index]--;
    }

    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

// Hàm Radix Sort tùy chỉnh để sắp xếp theo tổng các chữ số
void radixSort(vector<int>& arr) {
    int n = arr.size();
    vector<int> digitSums(n);
    for (int i = 0; i < n; i++) {
        digitSums[i] = sumOfDigits(arr[i]);
    }

    int maxSum = getMaxSum(digitSums);
    for (int exp = 1; maxSum / exp > 0; exp *= 10) {
        countingSort(arr, digitSums, exp);
    }
}

int main() {
    vector<int> arr = {39, 8, 5, 1, 3, 6, 9, 12, 4, 7, 10};
    
    cout << "Mảng ban đầu: ";
    for (int num : arr) {
        cout << num << " ";
    }
    cout << endl;
    
    radixSort(arr);
    
    cout << "Mảng sau khi sắp xếp theo tổng các chữ số: ";
    for (int num : arr) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
