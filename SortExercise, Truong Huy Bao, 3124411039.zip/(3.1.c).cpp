#include <vector>
#include <iostream>
#include <cmath>
using namespace std;

// Hàm kiểm tra số nguyên tố
bool isPrime(int n) {
    if (n <= 1) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (int i = 5; i <= sqrt(n); i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}

// Hàm để xóa các số nguyên tố khỏi dãy số
void removePrimes(vector<int>& arr) {
    auto it = arr.begin();
    while (it != arr.end()) {
        if (isPrime(*it)) {
            it = arr.erase(it);
        } else {
            ++it;
        }
    }
}

int main() {
    vector<int> arr = {39, 8, 5, 1, 3, 6, 9, 12, 4, 7, 10};
    
    cout << "Dãy số trước khi xóa số nguyên tố: ";
    for (int num : arr) {
        cout << num << " ";
    }
    cout << endl;
    
    removePrimes(arr);
    
    cout << "Dãy số sau khi xóa số nguyên tố: ";
    for (int num : arr) {
        cout << num << " ";
    }
    cout << endl; return 0;

    return 0;
}
