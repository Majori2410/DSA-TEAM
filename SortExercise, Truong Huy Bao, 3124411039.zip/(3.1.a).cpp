#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Hàm hoán đổi 
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Hàm phân chia cho Quick Sort
int partition(vector<int> &arr, vector<int> &indices, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] > pivot) { // Sắp xếp giảm dần
            i++;
            swap(&arr[i], &arr[j]);
            swap(&indices[i], &indices[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    swap(&indices[i + 1], &indices[high]);
    return i + 1;
}

// Hàm Quick Sort
void quickSort(vector<int> &arr, vector<int> &indices, int low, int high) {
    if (low < high) {
        int pi = partition(arr, indices, low, high);
        quickSort(arr, indices, low, pi - 1);
        quickSort(arr, indices, pi + 1, high);
    }
}

int main() {
    vector<int> arr = {39, 8, 5, 1, 3, 6, 9, 12, 4, 7, 10};
    int n = arr.size();
    int k = 3; // Số phần tử lớn nhất cần lấy

    // Tạo mảng chỉ số ban đầu
    vector<int> indices(n);
    for (int i = 0; i < n; i++) {
        indices[i] = i;
    }

    // Sắp xếp mảng và chỉ số theo thứ tự giảm dần
    quickSort(arr, indices, 0, n - 1);

    // Lấy vị trí của k phần tử lớn nhất
    cout << "Vị trí của " << k << " phần tử lớn nhất: ";
    for (int i = 0; i < k; i++) {
        cout << indices[i] << " ";
    }
    cout << endl;

    return 0;
}

