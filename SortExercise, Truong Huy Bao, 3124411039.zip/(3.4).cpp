#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
// Kiểm tra số  nguyên tố
bool isPrime(int num) {
    if (num < 2) return false;
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) return false;
    }
    return true;
}
// Tìm số nguyên tố lớn nhất
int findLargestPrime(const vector<vector<int>>& matrix) {
    int largestPrime = -1;
    for (const auto& row : matrix) {
        for (int element : row) {
            if (isPrime(element) && element > largestPrime) {
                largestPrime = element;
}
        }
    }
    return largestPrime;
}
// Tìm dòng ít nhất có 1 số nguyên tố
vector<int> findRowsWithPrime(const vector<vector<int>>& matrix) {
    vector<int> rowsWithPrime;
    for (size_t i = 0; i < matrix.size(); ++i) {
        for (int element : matrix[i]) {
            if (isPrime(element)) {
                rowsWithPrime.push_back(i);
                break;
            }
        }
    }
    return rowsWithPrime;
}
// Tìm dòng tất cả đều là số nguyên tố
vector<int> findRowsWithAllPrimes(const vector<vector<int>>& matrix) {
    vector<int> rowsWithAllPrimes;
    for (size_t i = 0; i < matrix.size(); ++i) {
        bool allPrimes = true;
        for (int element : matrix[i]) {
            if (!isPrime(element)) {
                allPrimes = false;
                break;
            }
        }
        if (allPrimes) {
            rowsWithAllPrimes.push_back(i);
        }
    }
    return rowsWithAllPrimes;
}

int main() {
    vector<vector<int>> matrix = {
        {4, 6, 8, 9},
        {5, 7, 11, 13},
        {15, 16, 17, 19},
        {2, 3, 5, 7}
    };
int largestPrime = findLargestPrime(matrix);
vector<int> rowsWithPrime = findRowsWithPrime(matrix);
    vector<int> rowsWithAllPrimes = findRowsWithAllPrimes(matrix);

    cout << "Số nguyên tố lớn nhất trong ma trận: " << largestPrime << endl;
    cout << "Những dòng có chứa số nguyên tố: ";
    for (int row : rowsWithPrime) {
        cout << row << " ";
    }
    cout << endl;
    cout << "Những dòng chỉ chứa số nguyên tố: ";
    for (int row : rowsWithAllPrimes) {
        cout << row << " ";
    }
    cout << endl;

    return 0;
}
