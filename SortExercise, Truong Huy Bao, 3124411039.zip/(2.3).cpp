#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Hàm hoán đổi
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Sắp xếp đổi chỗ trực tiếp
void interchangeSort(int arr[], int n, int *compareCount, int *swapCount) {
    *compareCount = 0;
    *swapCount = 0;
    for (int i = 0; i < n-1; i++) {
        int minIdx = i; // Tìm phần tử nhỏ nhất
        for (int j = i+1; j < n; j++) {
            (*compareCount)++;
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        if (minIdx != i) { // Chỉ hoán đổi khi cần
            swap(&arr[i], &arr[minIdx]);
            (*swapCount)++;
        }
    }

}

// Sắp xếp chọn trực tiếp
void selectionSort(int arr[], int n, int *compareCount, int *swapCount) {
    *compareCount = 0;
    *swapCount = 0;
    for (int i = 0; i < n-1; i++) {
        int minIdx = i;
        for (int j = i+1; j < n; j++) {
            (*compareCount)++;
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        if (minIdx != i) {
            swap(&arr[i], &arr[minIdx]);
            (*swapCount)++;
        }
    }
}

// Sắp xếp chèn trực tiếp
void insertionSort(int arr[], int n, int *compareCount, int *swapCount) {
    *compareCount = 0;
    *swapCount = 0;
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j]> key) {
            (*compareCount)++;
            if (arr[j] > key) {
                arr[j + 1] = arr[j];
                (*swapCount)++;
            } else {
                break;
            }
            j--;
        }
        arr[j + 1] = key;
    }
}

// Bubble Sort có cờ


 
void bubbleSortFlagged(int arr[], int n, int *compareCount,  int*swapCount) {
    *compareCount = 0;
    *swapCount = 0;
    for (int i = 0; i < n-1; i++) {
        int swapped = 0;
        for (int j = 0; j < n-i-1; j++) {
            (*compareCount)++;
            if (arr[j] > arr[j+1]) {
                swap(&arr[j], &arr[j+1]);
                (*swapCount)++;
                swapped = 1;
            }
        }
        if (!swapped) break;
    }
}

// Bubble Sort không cờ
void bubbleSort(int arr[], int n, int *compareCount, int *swapCount) {
    *compareCount = 0;
    *swapCount = 0;
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            (*compareCount)++;
            if (arr[j] > arr[j+1]) {
                swap(&arr[j], &arr[j+1]);
                (*swapCount)++;
            }
        }
    }
}

// Phát sinh mảng ngẫu nhiên
void generateRandomArray(int arr[], int n, int max_value) {
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % (max_value + 1);
    }
}

// Thực nghiệm thuật toán
void experimentSortingAlgorithm(void (*sortFunc)(int[], int, int*, int*), int max_value, const char *sortName) {
    int sizes[] = {10, 100, 200, 500, 1000, 5000, 10000};
    int num_sizes = sizeof(sizes) / sizeof(sizes[0]);
    int t = 10; // Số lần thực nghiệm mỗi trường hợp

for (int i = 0; i < num_sizes; i++) {
        int n = sizes[i];
        double total_time = 0.0;
        int total_compare = 0;
        int total_swap = 0;

        for (int j = 0; j < t; j++) {
            int arr[n];
            generateRandomArray(arr, n, max_value);

            int compareCount = 0, swapCount = 0;
            clock_t start_time = clock();
            sortFunc(arr, n, &compareCount, &swapCount);
            clock_t end_time = clock();

            double time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
            total_time += time_taken;
            total_compare += compareCount;
            total_swap += swapCount;
        }

        double average_time = total_time / t;
        double average_compare = (double)total_compare / t;
        double average_swap = (double)total_swap / t;
        printf("Thuật toán: %s, Kích thước mảng: %d, Thời gian trung bình: %f giây, Số lần so sánh trung bình: %f, Số lần đổi chỗ trung bình: %f\n",
            sortName, n, average_time, average_compare, average_swap);
    }
}

int main() {
    srand(time(0)); // Khởi tạo seed cho hàm rand()
    
    printf("Thực nghiệm interchangeSort:\n");
    experimentSortingAlgorithm(interchangeSort, 10000, "Interchange Sort");

    printf("Thực nghiệm selectionSort:\n");
    experimentSortingAlgorithm(selectionSort, 10000, "Selection Sort");

    printf("Thực nghiệm insertionSort:\n");
    experimentSortingAlgorithm(insertionSort, 10000, "Insertion Sort");

    

    printf("Thực nghiệm bubbleSortFlagged:\n");
    experimentSortingAlgorithm(bubbleSortFlagged, 10000, "Bubble Sort (có cờ)");

    printf("Thực nghiệm bubbleSort:\n");
    experimentSortingAlgorithm(bubbleSort, 10000, "Bubble Sort (không cờ)");

    return 0;
}
